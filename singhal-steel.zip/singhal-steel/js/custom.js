
    'use strict';

    function initMiniSearch() {
        return {
            minSearchLength: 1,
            suggestions: [],
            suggest() {
                const search = this.$refs.searchInput;
                if (search.value.length >= this.minSearchLength) {
                    search.setCustomValidity('');
                    search.reportValidity();
                    this.fetchSuggestions(search.value);
                } else {
                    this.suggestions = [];
                }
            },
            fetchSuggestions(term) {
                fetch(
                    window.BASE_URL + 'search/ajax/suggest?' + new URLSearchParams({q: term}),
                    {
                        headers: {
                            'X-Requested-With': 'XMLHttpRequest'
                        }
                    }
                )
                .then(response => response.json())
                .then(result => this.suggestions = result);
            },
            search(term) {
                const search = this.$refs.searchInput;
                term = term || search.value;
                if (term.length < this.minSearchLength) {
                    search.setCustomValidity('Minimum\u0020Search\u0020query\u0020length\u0020is\u00201');
                    search.reportValidity();
                } else {
                    search.setCustomValidity('');
                    search.value = term;
                    this.$refs.form.submit();
                }
            },
            focusElement(element) {
                if (element && element.nodeName === "div") {
                    element.focus();
                    return true;
                } else {
                    return false;
                }
            }
        }
    }
  
        var searchEle = document.querySelector("#search");
        const popupDiv = document.getElementById("popupdiv");
        const animSearch1 = document.getElementById("animatedSearch");
        document.getElementById("animatedSearch").addEventListener("click", function(){
            searchEle.focus();
                            popupDiv.style.display='block';
             animSearch1.style.display='none';
        });
        document.getElementById("search").addEventListener("click", function(){
                            popupDiv.style.display='block';
             animSearch1.style.display='none';
        });
        document.getElementById("closepopupdiv").addEventListener("click", function(){
            popupDiv.style.display='none';
            animSearch1.style.display='flex';
        });

    
    const animSearch = document.getElementById("animatedSearch");
    var _CONTENT = ["Search for Baby Socks & Shoes", "Search for Baby Apparels", "Search for Teether", "Search for Carry Nest", "Search for Blankets", "Search for Bottle Feeder", "Search for Swaddles", "Search for Sleep Nest", "Search for Hair Booties", "Search for Hair Accessories"];
    var _PART = 0;
    var _PART_INDEX = 0;
    var _INTERVAL_VAL;
    var _ELEMENT = document.querySelector("#asfield");
    var _CURSOR = document.querySelector("#ascursor");
    function Type() {
        if (searchEle.value != "" || searchEle === document.activeElement) {
            animSearch.style.display='none';
            return false;
        }
        else{
            animSearch.style.display='flex';
        }
        var text =  _CONTENT[_PART].substring(0, _PART_INDEX + 1);
        _ELEMENT.innerHTML = text;
        _PART_INDEX++;
        if(text === _CONTENT[_PART]) {
            _CURSOR.style.display = 'none';

            clearInterval(_INTERVAL_VAL);
            setTimeout(function() {
                _INTERVAL_VAL = setInterval(Delete, 50);
            }, 1000);
        }
    }
    function Delete() {
        var text =  _CONTENT[_PART].substring(0, _PART_INDEX - 1);
        _ELEMENT.innerHTML = text;
        _PART_INDEX--;

        if(text === '') {
            clearInterval(_INTERVAL_VAL);

            if(_PART == (_CONTENT.length - 1))
                _PART = 0;
            else
                _PART++;

            _PART_INDEX = 0;

            setTimeout(function() {
                _CURSOR.style.display = 'inline-block';
                _INTERVAL_VAL = setInterval(Type, 100);
            }, 200);
        }
    }

    _INTERVAL_VAL = setInterval(Type, 100);

    $('.cs-sliders').slick({
        dots: true,
        infinite: false,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        autoplay: true,
        autoplayspeed: 2000,

        responsive: [
          {
            breakpoint: 1024,
            settings: {
              slidesToShow: 3,
              slidesToScroll: 3,
              infinite: true,
              dots: true
            }
          },
          {
            breakpoint: 600,
            settings: {
              slidesToShow: 2,
              slidesToScroll: 2
            }
          },
          {
            breakpoint: 480,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          }
          // You can unslick at a given breakpoint now by adding:
          // settings: "unslick"
          // instead of a settings object
        ]
      });